# mvvm
a simple mvvm platform

## demo_0
js 版本简单实现，功能包括双向数据绑定、视图渲染

## demo_1
ts 版本简单实现
